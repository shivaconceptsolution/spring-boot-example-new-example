package dao;

import java.util.Iterator;
import java.util.List;
import org.hibernate.cfg.*;
import org.hibernate.*;
import org.springframework.stereotype.Repository;
import services.Employees;
@Repository
public class EmployeeDAO {
	 private static Employees list= new Employees();
	 
	 public Employees getAllEmployees()
	 {
		    list.getEmployeeList().clear();
		    Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Query q = s.createQuery("from Employee e");
			List lst =   q.list();
			Iterator it = lst.iterator();
			while(it.hasNext())
			{
				
				Employee emp =(Employee) it.next();
				list.getEmployeeList().add(emp);
			}
			sf.close();
			s.close();
	     return list;
	 }
	 public void addEmployee(Employee employee)
      {
		    Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Transaction tx = s.beginTransaction();
			Employee obj = new Employee();
			obj.setEmpid(employee.getEmpid());
			obj.setEmpname(employee.getEmpname());
			obj.setJob(employee.getJob());
			s.save(obj);
			tx.commit();
			s.close();
			
           
      }
	 
	
	 
}
